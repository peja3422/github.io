var customIcons = {
      'Gas Station': {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_blue.png'
      },
      'Bulk Plant': {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_red.png'
      },
	  'Headquarters': {
		icon: 'http://labs.google.com/ridefinder/images/mm_20_green.png'
	  },
	  'Office': {
		  icon: 'http://labs.google.com/ridefinder/images/mm_20_black.png'
	  },
	  'Pacific Pride Cardlock': {
		  icon: 'http://labs.google.com/ridefinder/images/mm_20_orange.png'
	  }
};



function initialize() {
    var latlng = new google.maps.LatLng(43.0651553,-85.0525258);
	var myOptions = {
		zoom: 8,
		center: latlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		mapTypeControl: true,
		zoomControl: true,
		scrollwheel: true,
    };
	map = new google.maps.Map(document.getElementById('map'),myOptions);	
		
        markers = [];
		circles = [];
        
		
		
		
		  downloadUrl("http://localhost:8000/realMarkers.xml", function(mark) {
            var xml = mark.responseXML;
		    var data = xml.documentElement.getElementsByTagName("marker");
		    for (var i = 0; i < data.length; i++) {
		      latLng = new google.maps.LatLng(data[i].getAttribute("lat"), data[i].getAttribute("lng"));
			  var type = data[i].getAttribute("type");
			  var icon = customIcons[type];
              var marker = new google.maps.Marker({
                position: latLng,
			    map : map,
			    title : data[i].getAttribute("name"),
			    category : data[i].getAttribute("type"),
			    category2 : data[i].getAttribute("company"),
				icon : icon.icon,
              });
		      var circle = new google.maps.Circle({ 
			    center: latLng,
			    radius: 0.2*1.609344*1000, //convert 0.5 miles to meters
			    map:map,
			    fillOpacity: 0.0,
			    strokeWidth: 5,
			    title : data.Name,
		      });
		  	  markers.push(marker);
		      circles.push(circle);
		    // end Looping through the JSON data
		    <!-- Map traffic begin -->		
		    // end Creating a closure	  		  
            }
		  });
		  
		// var markerCluster = new MarkerClusterer(map, markers)	
		
		
		$('[name="type"],[name="company"]').click(function(){
		
		var criteria={type:[],company:[]};
		
		$.each(criteria,function(a,b){
		  $('[name="'+a+'"]').each(function(){
		    if(this.checked) criteria[this.name].push(this.value)
		  });
		})

		var expr=new RegExp('^('+criteria.company.join('|')+') ('+criteria.type.join('|')+')$');

		
		$.each(markers,function(){
		this.setMap(expr.test(this.getTitle())?map:null)
		});
		
		})
		
		$('[name="service"]').click(function() {
			for(var i = 0; i < circles.length; i++) {
				if (circles[i].getVisible()) { circles[i].setVisible(false); }
				else { circles[i].setVisible(true); }
			}
		
		})
}

google.maps.event.addDomListener(window, 'load', initialize);


function downloadUrl(url, callback) {
      var request = window.ActiveXObject ?
          new ActiveXObject('Microsoft.XMLHTTP') :
          new XMLHttpRequest;

      request.onreadystatechange = function() {
        if (request.readyState == 4) {
          request.onreadystatechange = doNothing;
          callback(request, request.status);
        }
      };

      request.open('GET', url, true);
      request.send(null);
    }
	
function doNothing() {}