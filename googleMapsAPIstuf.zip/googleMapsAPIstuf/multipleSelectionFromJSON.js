var json = [
{"Name" : "J&H Gas Station",
"Latitude" : 42.97255,
"Longitude" : -85.9414,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "6209 Lake Michigan Drive Allendale  MI 49401",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88504,
"Longitude" : -85.9041,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4842 Port Sheldon Road Hudsonville 49426",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88449,
"Longitude" : -86.1234,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "6363 - 136th Street Holland  MI 49424",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.90732,
"Longitude" : -85.8312,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1991 Baldwin Jenison  MI 49428",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.92102,
"Longitude" : -85.8107,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "8407 Cottonwood Jenison  MI 49428",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88551,
"Longitude" : -85.8363,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "2271 Port Sheldon Street Jenison  MI 49428",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.06287,
"Longitude" : -85.929,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "5 West Main Street Zeeland  MI 49464",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.82668,
"Longitude" : -86.0925,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "12575 Riley Street Holland  MI 49424",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.84882,
"Longitude" : -85.8613,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4200 32nd Ave. Hudsonville  MI 49426",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.81183,
"Longitude" : -85.9471,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "6420 Byron Road Zeeland  MI 49464",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88621,
"Longitude" : -85.7821,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4380 Kenowa Grandville  MI 49418",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.99025,
"Longitude" : -85.7528,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "3434 Remembrance Rd. Walker  MI 49534",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.80019,
"Longitude" : -86.1206,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "9673 Adams Street Holland  MI 49424",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.79399,
"Longitude" : -86.1542,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1140 Ottawa Beach Road Holland  MI 49424",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.93154,
"Longitude" : -85.7216,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "2257 Chicago Drive SW Wyoming  MI 49519",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.75912,
"Longitude" : -86.0969,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1122 Lincoln Avenue Holland  MI 49423",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.98158,
"Longitude" : -85.7107,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1229 Walker NW Grand Rapids  MI 49504",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.86326,
"Longitude" : -85.723,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "5568 Byron Center Avenue Wyoming  MI 49519",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.99584,
"Longitude" : -85.6882,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1760 Alpine Ave NW Grand Rapids  MI 49504",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.81187,
"Longitude" : -85.6692,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "293 84th St SW Byron Center  MI 49315",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.73353,
"Longitude" : -86.0616,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4360 Lincoln Road Holland  MI 49423",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.92781,
"Longitude" : -85.6748,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "335 Burton SW Grand Rapids  MI 49507",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.15445,
"Longitude" : -86.216,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1196 E Sternberg Muskegon  MI 49444",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88407,
"Longitude" : -85.6844,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4404 Clyde Park Ave SW Wyoming  MI 49509",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.00251,
"Longitude" : -85.6541,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "2171 Plainfield Rd. NE Grand Rapids  MI 49505",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.82614,
"Longitude" : -85.6744,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "460 76th Street Byron Center  MI 49315",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.68221,
"Longitude" : -86.0108,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "3604 Lincoln Road Hamilton  MI 49419",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.1197,
"Longitude" : -85.611,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "8501 Algoma Ave. NE Rockford  MI 49341",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.72496,
"Longitude" : -85.6743,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1331 142nd Street Wayland  MI 49348",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.85976,
"Longitude" : -85.5454,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4919 Town Center Drive Grand Rapids  MI 49512",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.17595,
"Longitude" : -85.5141,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "3620 14 Mile Road Cedar Springs  MI 49319",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.0864,
"Longitude" : -85.5084,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "6485 Belding Road Rockford  MI 49341",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.1802,
"Longitude" : -85.551,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "11800 Northland Drive Rockford  MI 49319",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.35571,
"Longitude" : -86.1674,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "5536 Holton Road Twin Lake  MI 49457",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.88054,
"Longitude" : -85.3711,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4475 Alden Nash Ave. Lowell  MI 49331",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.95696,
"Longitude" : -85.3544,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "432 Lincoln Lake Ave SE Vergennes Township  MI 49331",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.53699,
"Longitude" : -85.6539,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1190  116th Ave. Martin  MI 49070",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.3378,
"Longitude" : -85.4865,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "31774 W. Cannonsville Road Pierson  MI 49339",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.3957,
"Longitude" : -85.4615,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "580 West Shaw Howard City  MI 49329",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.42489,
"Longitude" : -85.4715,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "19504 Edgar Road Howard City  MI 49329",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.29247,
"Longitude" : -85.0851,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "319 W. Main Street Stanton  MI 48888",}
,{"Name" : "J&H Gas Station",
"Latitude" : 43.68915,
"Longitude" : -86.3813,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "4220 W. Polk Rd. Hart  MI 49420",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.72042,
"Longitude" : -84.494,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "1198 S. Harrison East Lansing  MI 48823",}
,{"Name" : "J&H Gas Station",
"Latitude" : 42.75536,
"Longitude" : -84.4627,
"Company" : "J&H",
"Type" : "Gas Station",
"Address" : "3010 E. Lake Lansing Road East Lansing  MI 48823",}
,{"Name" : "J&H Headquarters",
"Latitude" : 42.92589,
"Longitude" : -85.732,
"Company" : "J&H",
"Type" : "Headquarters",
"Address" : "2696 Chicago Drive SW Wyoming 49519",}
,{"Name" : "J&H Bulk Plant",
"Latitude" : 42.93562,
"Longitude" : -85.7068,
"Company" : "J&H",
"Type" : "Bulk Plant",
"Address" : "1619 Chicago Drive SW Wyoming 49519",}
,{"Name" : "J&H Bulk Plant",
"Latitude" : 41.9081,
"Longitude" : -86.0068,
"Company" : "J&H",
"Type" : "Bulk Plant",
"Address" : "604 Water Street Cassopolis 49031",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.88444,
"Longitude" : -85.7619,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "3980 44th Street Grandville MI 49418",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.97159,
"Longitude" : -85.7179,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "2035 Lake Michigan Dr  Grand Rapids MI 49504",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 43.01863,
"Longitude" : -85.6394,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "3110 Plainfield Ave NE  Grand Rapids MI 49505",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.80475,
"Longitude" : -86.0725,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "11372 East Lakewood Blvd Holland MI 49424",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.90046,
"Longitude" : -86.2096,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "9170 US-31 West Olive MI 49460",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.91279,
"Longitude" : -85.608,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "2411 28th St SE  Grand Rapids MI 49512",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.8046,
"Longitude" : -86.093,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "372 East Lakewood Blvd  Holland MI 49424",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.79532,
"Longitude" : -86.0841,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "543 Chicago Drive  Holland MI 49423",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.98379,
"Longitude" : -85.5909,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "1169 East Beltline NE  Grand Rapids MI 49525",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.91607,
"Longitude" : -85.5839,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "2560 East Beltline SE  Grand Rapids MI 49546",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 43.01533,
"Longitude" : -85.5899,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "2808 East Beltline NE  Grand Rapids MI 49525",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.74602,
"Longitude" : -86.0733,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "762 Cabill Ave Holland MI 49423",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.69386,
"Longitude" : -85.981,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "3416 M-40  Hamilton MI 49419",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.74516,
"Longitude" : -85.5997,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "9633 Cherry Valley Caledonia Mi 49316",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 43.23443,
"Longitude" : -86.1572,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "3592 East Apple Ave.  Muskegon MI 49442",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 43.19093,
"Longitude" : -86.2621,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "782 West Norton Ave  Muskegon MI 49441",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.59444,
"Longitude" : -86.1018,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "409 East Main Street  Fennville MI 49408",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.93507,
"Longitude" : -85.3356,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "403 West Main St Lowell MI 49331",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.62841,
"Longitude" : -85.544,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "1515 South Patterson Road Wayland MI 49348",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 42.6316,
"Longitude" : -85.5066,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "11300 W M-179 HWY Middleville MI 49333",}
,{"Name" : "Merle Boes Gas Station",
"Latitude" : 43.26644,
"Longitude" : -86.2507,
"Company" : "Merle Boes",
"Type" : "Gas Station",
"Address" : "176 Whitehall Rd North Muskegon MI 49445",}
,{"Name" : "Merle Boes Headquarters",
"Latitude" : 42.80475,
"Longitude" : -86.0725,
"Company" : "Merle Boes",
"Type" : "Headquarters",
"Address" : "11372 E Lakewood Blvd Holland MI 49424",}
,{"Name" : "Coyne Headquarters",
"Latitude" : 43.61189,
"Longitude" : -84.7861,
"Company" : "Coyne",
"Type" : "Headquarters",
"Address" : "914 West Pickard St. Mount Pleasant  MI 48858",}
,{"Name" : "Coyne Bulk Plant",
"Latitude" : 44.33528,
"Longitude" : -85.5491,
"Company" : "Coyne",
"Type" : "Bulk Plant",
"Address" : "4986 M-115 Cadillac  MI 49601",}
,{"Name" : "Coyne Bulk Plant",
"Latitude" : 43.82109,
"Longitude" : -84.7778,
"Company" : "Coyne",
"Type" : "Bulk Plant",
"Address" : "513 W Fifth St Clare  MI 48617",}
,{"Name" : "Coyne Bulk Plant",
"Latitude" : 43.90035,
"Longitude" : -85.2896,
"Company" : "Coyne",
"Type" : "Bulk Plant",
"Address" : "10089 US 10 Evart  MI 49631",}
,{"Name" : "Coyne Bulk Plant",
"Latitude" : 43.41033,
"Longitude" : -84.3302,
"Company" : "Coyne",
"Type" : "Bulk Plant",
"Address" : "136 N Midland St Merrill  MI 48637",}
,{"Name" : "Atlas Headquarters",
"Latitude" : 42.25548,
"Longitude" : -83.2747,
"Company" : "Atlas",
"Type" : "Headquarters",
"Address" : "24501 Ecorse Road Taylor  MI 48180",}
,{"Name" : "Atlas Bulk Plant",
"Latitude" : 41.78359,
"Longitude" : -86.2525,
"Company" : "Atlas",
"Type" : "Bulk Plant",
"Address" : "1001 Fulkerson Road Niles  MI 49120",}
,{"Name" : "Atlas Bulk Plant",
"Latitude" : 41.62747,
"Longitude" : -83.6116,
"Company" : "Atlas",
"Type" : "Bulk Plant",
"Address" : "2925 Airport Highway Toledo  OH 43609",}
,{"Name" : "Petersen Headquarters",
"Latitude" : 43.20121,
"Longitude" : -85.2531,
"Company" : "Petersen",
"Type" : "Headquarters",
"Address" : "6360 Greenville Road Greenville  MI 48838",}
,{"Name" : "Petersen Office",
"Latitude" : 42.8862,
"Longitude" : -85.0723,
"Company" : "Petersen",
"Type" : "Office",
"Address" : "75 E Grand River Ave. Ionia  MI 48846",}
,{"Name" : "Petersen Gas Station",
"Latitude" : 43.20121,
"Longitude" : -85.2531,
"Company" : "Petersen",
"Type" : "Gas Station",
"Address" : "6360 Greenville Road Greenville  MI 48838",}
,{"Name" : "Petersen Gas Station",
"Latitude" : 42.8862,
"Longitude" : -85.0723,
"Company" : "Petersen",
"Type" : "Gas Station",
"Address" : "75 E Grand River Ave. Ionia  MI 48846",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 43.40811,
"Longitude" : -84.4491,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "8057 Monroe Road Wheeler 48662",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.29094,
"Longitude" : -83.156,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "500 South Dix Detroit 48217",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.16457,
"Longitude" : -84.263,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "7925 Napoleon Road Jackson 49201",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.18901,
"Longitude" : -84.0322,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "9050 MI State Road 52 Manchester 48158",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.03319,
"Longitude" : -83.6855,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "11204 Cone Road Milan 48160",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 43.43777,
"Longitude" : -83.9815,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "3057 Davenport Avenue Saginaw 48602",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 41.63794,
"Longitude" : -83.6143,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "3015 Hill Avenue Toledo 43607",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.42991,
"Longitude" : -83.769,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "11818 Whitmore Lake Road Whitmore Lake 48189",}
,{"Name" : "Corrigan Bulk Plant",
"Latitude" : 42.194,
"Longitude" : -83.1664,
"Company" : "Corrigan",
"Type" : "Bulk Plant",
"Address" : "3810 11th Street Wyandotte 48192",}
,{"Name" : "Corrigan Headquarters",
"Latitude" : 42.53612,
"Longitude" : -83.7868,
"Company" : "Corrigan",
"Type" : "Headquarters",
"Address" : "775 North 2nd Street Brighton 48116",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.41456,
"Longitude" : -83.8977,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "3366 Holland Saginaw  MI 48601",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.43689,
"Longitude" : -84.004,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "4480 State Street Saginaw  MI 48602",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.44618,
"Longitude" : -83.9756,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "2791 Bay Road Saginaw  MI 48603",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.4504,
"Longitude" : -83.8878,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "3670 East Washington Saginaw  MI 48601",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.41544,
"Longitude" : -83.9668,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "408 South Michigan Avenue Saginaw  MI 48602",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.40053,
"Longitude" : -83.9359,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "2303 Hess Street Saginaw  MI 48601",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.41561,
"Longitude" : -84.0522,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "7015 Gratiot Saginaw  MI 48609",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.4368,
"Longitude" : -83.9912,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "3540 State Street Saginaw  MI 48602",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.61056,
"Longitude" : -83.9147,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "806 North Euclid Bay City  MI 48706",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.56391,
"Longitude" : -83.8437,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "56 S tuscola Rd Bay City  MI 48708",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.26711,
"Longitude" : -84.4237,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "1612 North West Avenue Jackson  MI 49202",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.23952,
"Longitude" : -84.3533,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "3465 Page Ave Jackson  MI 49203",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.27731,
"Longitude" : -84.311,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "6010 Ann Arbor Road Jackson  MI 49201",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.00227,
"Longitude" : -83.7527,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "3930 Corunna Road Flint  MI 48532",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.25003,
"Longitude" : -83.7798,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "8830 Main Street Birch Run  MI 48415",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.12003,
"Longitude" : -83.676,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "8010 N Dort Hwy Mt. Morris  MI 48458",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.56215,
"Longitude" : -83.7921,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "8340 Grand River Brighton  MI 48114",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.61822,
"Longitude" : -83.2487,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "1500 South Opdyke Pontiac  MI 48341",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.18859,
"Longitude" : -84.1688,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "15815 South Oakley Chesaning  MI 48616",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.4101,
"Longitude" : -84.3313,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "105 West Saginaw Merrill  MI 48637",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.61072,
"Longitude" : -84.3944,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "633 West Isabella Midland  MI 48640",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 42.58206,
"Longitude" : -84.4517,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "551 West Columbia Street Mason  MI 48854",}
,{"Name" : "Corrigan Gas Station",
"Latitude" : 43.85451,
"Longitude" : -84.0658,
"Company" : "Corrigan",
"Type" : "Gas Station",
"Address" : "520 Pinconning Road Pinconning 48650  MI 48650",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.31791,
"Longitude" : -86.2616,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3003 Whitehall Rd Muskegon   MI 49445",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.95603,
"Longitude" : -86.4161,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5445 U.S. 10 Ludington   MI 49431",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.4399,
"Longitude" : -84.7902,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7640 U.S. 31 Alanson   MI 49706",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.9749,
"Longitude" : -84.9738,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4162 1st St Alba   MI 49611",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.39297,
"Longitude" : -84.6467,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1450 Bridge Ave Alma   MI 48801",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.36833,
"Longitude" : -84.6624,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "6122 N State Rd Alma   MI 48801",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.40807,
"Longitude" : -84.6539,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2400 W Monroe Rd Alma   MI 48801",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.07142,
"Longitude" : -83.444,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1035 W Chisholm St Alpena   MI 49707",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.04431,
"Longitude" : -83.4554,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2222 U.S. 23 Alpena   MI 49707",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.0498,
"Longitude" : -83.4449,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1000 Hwy 32 Alpena   MI 49707",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.02975,
"Longitude" : -85.6896,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3623 Alpine Ave NW Comstock Park   MI 49321",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.86492,
"Longitude" : -85.8466,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1210 Michigan Ave Baldwin   MI 49304",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.36992,
"Longitude" : -84.9782,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1087 U.S. 31 Petoskey   MI 49770",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.43288,
"Longitude" : -86.1279,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "12348 U.S. 31 Bear Lake   MI 49614",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.63171,
"Longitude" : -86.0921,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "85 S Benzie Blvd Beulah   MI 49617",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.70615,
"Longitude" : -85.484,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "710 S State St Big Rapids   MI 49307",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.92923,
"Longitude" : -85.8408,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "9505 M-37 Baldwin   MI 49304",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.16428,
"Longitude" : -84.918,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2568 U.S. 131 Boyne Falls   MI 49713",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.30601,
"Longitude" : -86.0213,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4584 N High Bridge Rd Brethren   MI 49619",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.65529,
"Longitude" : -85.8114,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7586 N Woodbridge Rd White Cloud   MI 49349",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.27817,
"Longitude" : -85.4068,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1947 N Mitchell St Cadillac   MI 49601",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.33528,
"Longitude" : -85.5491,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "6224 M-115 Cadillac   MI 49601",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.17682,
"Longitude" : -84.8453,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "105 E Main St Carson City   MI 48811",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.06047,
"Longitude" : -85.2642,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1806 S Main St Central Lake   MI 49622",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.31247,
"Longitude" : -85.2587,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1460 Bridge St Charlevoix   MI 49720",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.32748,
"Longitude" : -85.2332,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "12665 US-31 Charlevoix   MI 49720",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.7658,
"Longitude" : -85.6347,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "365 US-31 Traverse City   MI 49685",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.83725,
"Longitude" : -84.7682,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "10400 S Clare Ave Clare   MI 48617",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.19044,
"Longitude" : -86.1563,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3576 Heights Ravenna Rd Muskegon   MI 49444",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.76534,
"Longitude" : -84.5864,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5246 N Coleman Rd Coleman   MI 48618",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.92923,
"Longitude" : -85.8408,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4210 M-37 Baldwin   MI 49304",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.47535,
"Longitude" : -85.9199,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "18866 Cadillac Hwy Copemish   MI 49625",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.44902,
"Longitude" : -85.6486,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7333 S Croton Hardy Dr Newaygo   MI 49337",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.70559,
"Longitude" : -83.7875,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2541 M-65 Curran   MI 48728",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.24561,
"Longitude" : -86.3185,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "313 1st St Manistee   MI 49660",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.07731,
"Longitude" : -86.2154,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "123 Pine St Spring Lake   MI 49456",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.17925,
"Longitude" : -85.9356,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "18349 Hoxeyville Rd Wellston   MI 49689",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.15396,
"Longitude" : -85.1399,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "651 Water St East Jordan   MI 49727",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.89394,
"Longitude" : -85.4141,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1st St 1st St Elk Rapids   MI 49629",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.06549,
"Longitude" : -84.8979,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2400 US-131 Elmira   MI 49730",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.81127,
"Longitude" : -86.0543,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "9988 W Front St Empire   MI 49630",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.90041,
"Longitude" : -85.2621,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "310 W 7th St Evart   MI 49631",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.31414,
"Longitude" : -84.6314,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "567 E Houghton Lake Dr Denton Township   MI 48651",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.6139,
"Longitude" : -85.5261,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4946 Garfield Rd Kingsley   MI 49649",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.22274,
"Longitude" : -86.3065,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2421 Manistee Hwy Manistee   MI 49660",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.63261,
"Longitude" : -86.2373,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "629 Main St Frankfort   MI 49635",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.46704,
"Longitude" : -85.9622,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1028 W Main St Fremont   MI 49412",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.99357,
"Longitude" : -84.677,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2678 S Otsego Ave Gaylord   MI 49735",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.06072,
"Longitude" : -86.2207,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1 S Beacon Blvd Grand Haven   MI 49417",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.66052,
"Longitude" : -84.7134,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "608 Cedar St Grayling   MI 49738",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.66052,
"Longitude" : -84.7134,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "608 S James St Grayling   MI 49738",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.17729,
"Longitude" : -85.2518,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "115 E Washington St Greenville   MI 48838",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.43168,
"Longitude" : -84.992,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3473 M-119 Harbor Springs   MI 49740",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.44203,
"Longitude" : -84.9906,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "105 Franklin St Harbor Springs   MI 49740",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.44667,
"Longitude" : -84.9904,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7701 S State St Harbor Springs   MI 49740",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.06911,
"Longitude" : -84.7977,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5778 N Clare Ave Harrison   MI 48625",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.0263,
"Longitude" : -84.8037,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "701 N 1st St Harrison   MI 48625",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.6386,
"Longitude" : -83.3067,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "449 US 23 Harrisville   MI 48740",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.70481,
"Longitude" : -86.3635,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "223 N State St Hart   MI 49420",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.68887,
"Longitude" : -86.3822,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4279 W Polk Rd Hart   MI 49420",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.56884,
"Longitude" : -86.0398,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "11 N Division St Hesperia   MI 49421",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.81218,
"Longitude" : -86.0893,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "12481 James St Holland   MI 49424",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.30007,
"Longitude" : -84.7423,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5175 W Houghton Lake Dr Houghton Lake   MI 48629",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.37399,
"Longitude" : -84.6296,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "4524 S Straits Hwy Indian River   MI 49749",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.44721,
"Longitude" : -84.578,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "6220 M-68 Indian River   MI 49749",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.65894,
"Longitude" : -85.8162,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "9419 U.S. 31 Interlochen   MI 49643",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.14049,
"Longitude" : -85.9119,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5456 West 10 1/2 Mile Road Irons   MI 49644",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.2918,
"Longitude" : -84.5763,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1427 E Washington Rd Ithaca   MI 48847",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.2915,
"Longitude" : -84.5927,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1420 E Center St Ithaca   MI 48847",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.37793,
"Longitude" : -86.0412,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "14210 9 Mile Rd Kaleva   MI 49645",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.33815,
"Longitude" : -85.2146,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "414 N Main St Lake City   MI 49651",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.74122,
"Longitude" : -84.5924,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3206 W Saginaw St Lansing   MI 48917",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.7412,
"Longitude" : -84.66,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7404 W Saginaw Hwy Lansing   MI 48917",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.72673,
"Longitude" : -84.6399,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "6300 W St Joe Hwy Lansing   MI 48917",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.71365,
"Longitude" : -84.603,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1700 S Waverly Rd Lansing   MI 48917",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.956,
"Longitude" : -86.4277,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5985 US-10 Ludington   MI 49431",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.89537,
"Longitude" : -85.0684,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "608 S Williams St Mancelona   MI 49659",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.56757,
"Longitude" : -84.4403,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "216 W Kipp Rd Mason   MI 48854",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.40581,
"Longitude" : -85.7244,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "445 W Mesick Ave Mesick   MI 49668",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.17612,
"Longitude" : -84.751,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5300 W Cleveland Rd Middleton   MI 48856",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.75688,
"Longitude" : -85.5757,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "509 Munson Ave Traverse City   MI 49686",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.588,
"Longitude" : -84.7674,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1911 S Mission St Mt Pleasant   MI 48858",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.59736,
"Longitude" : -84.7677,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "718 S Mission St Mt Pleasant   MI 48858",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.61135,
"Longitude" : -84.7317,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5612 E Pickard Rd Mt Pleasant   MI 48858",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 46.41106,
"Longitude" : -86.6479,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "401 M-28 Munising   MI 49862",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.41905,
"Longitude" : -85.8013,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "68 State Rd Newaygo   MI 49337",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.27782,
"Longitude" : -86.2359,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1385 Holton Rd Muskegon   MI 49445",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.19058,
"Longitude" : -86.2633,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3416 Henry St Muskegon   MI 49441",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.074,
"Longitude" : -86.0856,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "11956 Cleveland St Nunica   MI 49448",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.60762,
"Longitude" : -84.5882,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "48 S Coleman Rd Mt Pleasant   MI 48858",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.90932,
"Longitude" : -83.4429,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "11596 US-23 Sanborn Township   MI 49766",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.27062,
"Longitude" : -86.2833,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1021 E Parkdale Ave Manistee   MI 49660",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.82671,
"Longitude" : -86.1342,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "945 Butternut Dr Holland   MI 49424",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.46663,
"Longitude" : -84.9131,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5667 Pleasantview Rd Harbor Springs   MI 49740",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.26809,
"Longitude" : -83.699,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "10706 Michigan Ave Posen   MI 49776",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.29852,
"Longitude" : -84.6852,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2403 W Houghton Lake Dr Denton Township   MI 48651",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.83456,
"Longitude" : -85.2829,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "8227 Rapid City Rd NW Rapid City   MI 49676",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.88761,
"Longitude" : -85.533,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "22522 U.S. 10 Reed City   MI 49677",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.59668,
"Longitude" : -85.149,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3559 W Wheatland Ave Remus   MI 49340",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.62925,
"Longitude" : -84.4794,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "912 S Main St Cheboygan   MI 49721",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.41026,
"Longitude" : -83.8251,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "101 S Bradley Hwy Rogers City   MI 49779",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.41522,
"Longitude" : -84.1161,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "619 S Bennett St Rose City   MI 48654",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.95498,
"Longitude" : -86.2724,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "423 US-10 Scottville   MI 49454",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.90134,
"Longitude" : -85.1478,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "6037 30th Ave Sears   MI 49679",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.52408,
"Longitude" : -84.6852,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "550 E Wright Ave Shepherd   MI 48883",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.21091,
"Longitude" : -85.0738,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "130 S Main St Sheridan   MI 48884",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 46.49685,
"Longitude" : -84.3455,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "210 E Spruce St Sault Ste. Marie   MI 49783",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 46.46321,
"Longitude" : -84.3732,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "709 W 3 Mile Rd Sault Ste. Marie   MI 49783",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.3628,
"Longitude" : -86.2005,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5028 Main St Onekama   MI 49675",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.9659,
"Longitude" : -84.5425,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3600 S US 27 St Johns   MI 48879",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 42.94299,
"Longitude" : -84.5431,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "1801 Old U.S. 27 St Johns   MI 48879",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.86808,
"Longitude" : -84.7247,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "200 S State St St Ignace   MI 49781",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.85667,
"Longitude" : -84.7343,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "917 U.S. 2 Saint Ignace   MI 49781",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.95468,
"Longitude" : -86.2781,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "101 E State St Scottville   MI 49454",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.26863,
"Longitude" : -86.2958,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "315 E Parkdale Ave Manistee   MI 49660",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.36153,
"Longitude" : -86.1965,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "5260 Main St Onekama   MI 49675",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.72692,
"Longitude" : -85.626,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "2925 Cass Rd Traverse City   MI 49684",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.69396,
"Longitude" : -85.6763,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "528 W Fourteenth St Traverse City   MI 49684",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 44.10345,
"Longitude" : -85.4444,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "20027 180th Ave Tustin   MI 49688",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.14683,
"Longitude" : -84.6644,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "8534 Mill St Vanderbilt   MI 49795",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 45.17991,
"Longitude" : -84.6732,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "10553 N Old 27 Gaylord   MI 49735",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.6834,
"Longitude" : -84.9686,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "3011 N Woodruff Rd Weidman   MI 48893",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.00126,
"Longitude" : -86.2005,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "11240 W Olive Rd Grand Haven   MI 49417",}
,{"Name" : "Blarney Castle Gas Station",
"Latitude" : 43.58813,
"Longitude" : -84.9077,
"Company" : "Blarney Castle",
"Type" : "Gas Station",
"Address" : "7961 S Winn Rd Mt Pleasant   MI 48858",}
,{"Name" : "Blarney Castle Headquarters",
"Latitude" : 44.42009,
"Longitude" : -86.1511,
"Company" : "Blarney Castle",
"Type" : "Headquarters",
"Address" : "12218 West Street Bear Lake MI 49614",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 45.04431,
"Longitude" : -83.4554,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "2222 US 23 South Alpena MI 49707",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 45.57703,
"Longitude" : -84.6248,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "6416 Riggsville Road Cheboygan MI 49721",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 43.3037,
"Longitude" : -86.193,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "2685 Holton Road North Muskegon MI 49445",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 44.81972,
"Longitude" : -85.283,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "7245 South Rapid City Road Rapid City MI 49676",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 43.88761,
"Longitude" : -85.533,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "22522 US 10 Reed City MI 49677",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 43.95467,
"Longitude" : -86.2705,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "578 W US 10 Scottville MI 49454",}
,{"Name" : "Blarney Castle Bulk Plant",
"Latitude" : 44.78077,
"Longitude" : -85.6408,
"Company" : "Blarney Castle",
"Type" : "Bulk Plant",
"Address" : "10827 E Carter Road Traverse City MI 49684",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 41.59959,
"Longitude" : -87.1727,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "1811 Armstrong Street Portage  IN 46368",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.50435,
"Longitude" : -85.7993,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "1177 Lincoln Road Allegan  MI 49010",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.31878,
"Longitude" : -85.2218,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "2200 West Dickman Road Battle Creek  MI 49037",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.81805,
"Longitude" : -85.6813,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "7599 Clyde Park SW Byron Center  MI 49315",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 43.04568,
"Longitude" : -85.9566,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "15652 68th Ave Coopersville  MI 49404",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.99383,
"Longitude" : -85.7451,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "3744 3 Mile Rd NW Grand Rapids  MI 49544-1234",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.95325,
"Longitude" : -85.6706,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "150 Pleasant St SW Grand Rapids  MI 49503",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.89806,
"Longitude" : -85.6464,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "3611 Eastern SE Grand Rapids  MI 49508",}
,{"Name" : "Van Manen Headquarters",
"Latitude" : 42.96444,
"Longitude" : -85.7872,
"Company" : "Van Manen",
"Type" : "Headquarters",
"Address" : "O-305 Lake Michigan Dr Grand Rapids  MI 49534",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.91333,
"Longitude" : -85.6571,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "2763 Madison SE Grand Rapids  MI 49507",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 43.00688,
"Longitude" : -85.6789,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "2400 Turner Ave NW Grand Rapids  MI 49544",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.84589,
"Longitude" : -85.8556,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "4245 Corporate Exchange Dr Hudsonville  MI 49426",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.88926,
"Longitude" : -85.8406,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "2353 Wilshere Jenison  MI 49428",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.31466,
"Longitude" : -85.6305,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "3320 Ravine Road Kalamazoo  MI 49006",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.27067,
"Longitude" : -85.6383,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "3821 Stadium Drive Kalamazoo  MI 49008",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.89819,
"Longitude" : -85.5656,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "4121 36th St SE  Kentwood  MI 49512",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.92987,
"Longitude" : -85.3841,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "11630 E. Fulton St Lowell  MI 49331",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.53771,
"Longitude" : -85.6415,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "1613 North Main Martin  MI 49070",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.45007,
"Longitude" : -85.66,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "1198 M-89 Plainwell  MI 49080",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.40309,
"Longitude" : -86.2736,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "72400 County Road 388 South Haven  MI 49090",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.85969,
"Longitude" : -85.6764,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "5755 Clay Ave Wyoming  MI 49548",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.6718,
"Longitude" : -85.662,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "3454 12th Street Wayland  MI 49348",}
,{"Name" : "Van Manen Pacific Pride Cardlock",
"Latitude" : 42.95325,
"Longitude" : -85.6706,
"Company" : "Van Manen",
"Type" : "Pacific Pride Cardlock",
"Address" : "150 Pleasant St SW Grand Rapids MI 49503",}
,{"Name" : "Foster Blue Water Headquarters",
"Latitude" : 42.83891,
"Longitude" : -82.7996,
"Company" : "Foster Blue Water",
"Type" : "Headquarters",
"Address" : "36065 Water Street Richmond  MI 48062",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.12146,
"Longitude" : -83.3196,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "69120 Foster Road Richmond  MI 48062",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.34302,
"Longitude" : -83.8323,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "448 Country Center Lapeer  MI 48446",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.7378,
"Longitude" : -83.9333,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "6101 Baron Drive Bridgeport  MI 48722",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.00147,
"Longitude" : -84.8439,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "1694 Marquette Avenue Bay City  MI 48707",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.60666,
"Longitude" : -84.2287,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "326 East Main Street Pewamo  MI 48873",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 44.06241,
"Longitude" : -84.8039,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "1602 East Grove Midland  MI 48640",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 44.27662,
"Longitude" : -84.0774,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "5180 North Clare Harrison  MI 48625",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 44.64528,
"Longitude" : -84.13,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "1985 West Tawas Road West Branch  MI 48661",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 43.21258,
"Longitude" : -82.5276,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "308 South Morenci Avenue Mio  MI 48647",}
,{"Name" : "Foster Blue Water Bulk Plant",
"Latitude" : 42.81201,
"Longitude" : -82.7529,
"Company" : "Foster Blue Water",
"Type" : "Bulk Plant",
"Address" : "7430 South Lakeshore Dr Lexington  MI 48450",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 42.90947,
"Longitude" : -82.5005,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "4565 Gratiot Road Smiths Creek  MI 48074",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 42.83891,
"Longitude" : -82.7996,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "37150 31 Mile Road Richmond  MI 48062",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 42.9584,
"Longitude" : -82.4521,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "2319 24th Street Port Huron  MI 48060",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 43.04373,
"Longitude" : -82.4568,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "4664 24th Avenue Fort Gratiot  MI 48059",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 42.72747,
"Longitude" : -82.5101,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "6040 King Road Marine City  MI 48039",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 44.26937,
"Longitude" : -84.2307,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "2288 Refinery Rd. West Branch  MI 48661",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 44.0623,
"Longitude" : -84.804,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "5170 N Clare Ave Harrison  MI 48625",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 43.67797,
"Longitude" : -84.3683,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "2278 N Meridian Sanford  MI 48657",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 43.61089,
"Longitude" : -84.2064,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "1920 James Savage Rd. Midland  MI 48642",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 43.60666,
"Longitude" : -84.2287,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "1602 East Grove St Midland  MI 48640",}
,{"Name" : "Foster Blue Water Pacific Pride Cardlock",
"Latitude" : 42.98501,
"Longitude" : -82.9275,
"Company" : "Foster Blue Water",
"Type" : "Pacific Pride Cardlock",
"Address" : "3200 Capac Rd Capac  MI 48014",}
,{"Name" : "Crystal Flash Headquarters",
"Latitude" : 42.995664,
"Longitude" : -85.688199,
"Company" : "Crystal Flash",
"Type" : "Headquarters",
"Address" : "1754 Alpine Avenue NW Grand Rapids MI 49504",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 44.2647073,
"Longitude" : -85.4673351,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "5051 E M-115 Rd Cadillac MI 49601",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 42.944005,
"Longitude" : -85.346913,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "1102 Lincoln Lake Lowell MI 49331",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 43.983466,
"Longitude" : -84.482694,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "420 N State St Gladwin MI 48624",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 42.276478,
"Longitude" : -84.931235,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "1021 E Michigan Marshall MI 49068",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 41.91238,
"Longitude" : -83.389605,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "87 Jerome St Monroe MI 48161",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 43.490217,
"Longitude" : -85.610936,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "7667 E 36th St Newaygo MI 49337",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 43.192143,
"Longitude" : -85.230538,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "605 Industrial Park Dr Greenville MI 48838",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 42.202085,
"Longitude" : -85.874561,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "59561 S Lagrave St Paw Paw MI 49079",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 42.66656,
"Longitude" : -85.989827,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "4523 134th Ave Hamilton MI 49419",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 42.135078,
"Longitude" : -85.656846,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "225 Elm St Schoolcraft MI 49087",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 45.065468,
"Longitude" : -83.899515,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "16309 County Rd Hillman MI 49746",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 44.698246,
"Longitude" : -85.654642,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "896 West Blue Star Dr Traverse City MI 49685",}
,{"Name" : "Crystal Flash Bulk Plant",
"Latitude" : 43.274659,
"Longitude" : -86.239409,
"Company" : "Crystal Flash",
"Type" : "Bulk Plant",
"Address" : "1231 Holton Rd Muskegon MI 49445",}
]


var customIcons = {
  'Gas Station': {
    icon: 'http://maps.google.com/mapfiles/marker_blackG.png'
  },
  'Bulk Plant': {
    icon: 'http://maps.google.com/mapfiles/markerB.png'
  },
	'Headquarters': {
		icon: 'http://maps.google.com/mapfiles/marker_yellowH.png'
	},
	'Office': {
	  icon: 'http://maps.google.com/mapfiles/marker_whiteO.png'
	},
	'Pacific Pride Cardlock': {
	  icon: 'http://maps.google.com/mapfiles/marker_brownP.png'
	},
	'Crystal Flash': {
		icon: '_black'
	},
	'Corrigan': {
		icon: '_grey'
	},
	'Blarney Castle': {
		icon: '_green'
	},
	'Petersen': {
		icon: '_white'
	},
	'Atlas': {
		icon: '_yellow'
	},
	'Van Manen': {
		icon: '_brown'
	},
	'Coyne': {
		icon: ''
	},
	'Merle Boes': {
		icon: '_orange'
	},
	'J&H': {
		icon: 'purple'
	}
};



function initialize() {
    var latlng = new google.maps.LatLng(43.0651553,-85.0525258);
	  var myOptions = {
		  zoom: 8,
		  center: latlng,
		  mapTypeId: google.maps.MapTypeId.ROADMAP,
		  mapTypeControl: true,
		  zoomControl: true,
		  scrollwheel: true,
    };
	  map = new google.maps.Map(document.getElementById('map'),myOptions);	
    markers = [];
		circles = [];
        
		    for (var i = 0; i < json.length; i++) {
		      var data = json[i];
					latLng = new google.maps.LatLng(data.Latitude, data.Longitude);
			    var type = data.Type;
			    var icon = customIcons[type];
          var marker = new google.maps.Marker({
            position: latLng,
			      map : map,
			      title : data.Name,
			      category : data.Type,
			      category2 : data.Company,
					  icon : icon.icon
          });
				  if (data.Company == "Crystal Flash") {
		        var circle = new google.maps.Circle({ 
			        center: latLng,
			        radius: 16093*3, //30 miles in meters
			        map:map,
			        fillOpacity: 0.0,
			        strokeWidth: 1,
			        title : data.Name
		        });
						circles.push(circle);
					}
		  	  markers.push(marker);
		      
		    // end Looping through the JSON data
		    <!-- Map traffic begin -->		
		    // end Creating a closure	  		  
        };
		  
		// var markerCluster = new MarkerClusterer(map, markers)	
		
		
		$('[name="type"],[name="company"]').click(function(){
		
		var criteria={type:[],company:[]};
		
		$.each(criteria,function(a,b){
		  $('[name="'+a+'"]').each(function(){
		    if(this.checked) criteria[this.name].push(this.value)
		  });
		})

		var expr=new RegExp('^('+criteria.company.join('|')+') ('+criteria.type.join('|')+')$');

		
		$.each(markers,function(){
		this.setMap(expr.test(this.getTitle())?map:null)
		});
		
		})
		
		$('[name="service"]').click(function() {
			for(var i = 0; i < circles.length; i++) {
				if (circles[i].getVisible()) { circles[i].setVisible(false); }
				else { circles[i].setVisible(true); }
			}
		
		})
}

google.maps.event.addDomListener(window, 'load', initialize);


