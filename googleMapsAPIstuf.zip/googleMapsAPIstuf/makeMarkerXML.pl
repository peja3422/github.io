#!/usr/bin/perl -w

open(IN,"altogetherNow.csv");
open(OUT,">realMarkers.xml");
my $i = 0;
print OUT "<markers>\n";
<IN>;
while(<IN>) {
	chomp($_);
	my ($address,$company,$type,$lat,$lng,$name) = split(/,/);
	#if($i < 10) {print "$company\t$type\t$name\n";}
	print OUT "<marker name=\"$name\" address=\"$address\" lat=\"$lat\" lng=\"$lng\" company=\"$company\" type=\"$type\"/>\n";
	$i++;
}
print OUT "</markers>"
#print $a;