var json = [{
		"Name" : "NER 1",
		"Latitude" : 51.50732,
		"Longitude" : -0.128673,
		"Connect" : "BS123",
		"ChargeR" : "Standard",
		"Contype" : 1,
		"Operator" : "NER",
	},{
		"Name" : "NER 2",
		"Latitude" : 51.506906,
		"Longitude" : -0.126548,
		"Connect" : "BS234",
		"ChargeR" : "Standard",
		"Contype" : 2,
		"Operator" : "NER",
	},{
		"Name" : "SEW 3",
		"Latitude" : 51.508382,
		"Longitude" : -0.129724,
		"Connect" : "BS345",
		"ChargeR" : "Standard",
		"Contype" : 3,
		"Operator" : "SEW",
	},{
		"Name" : "SEW 1",
		"Latitude" : 51.508322,
		"Longitude" : -0.126902,
		"Connect" : "BS123",
		"ChargeR" : "Standard",
		"Contype" : 1,
		"Operator" : "SEW",
	},{
		"Name" : "TAW 2",
		"Latitude" : 51.507841,
		"Longitude" : -0.126066,
		"Connect" : "BS234",
		"ChargeR" : "Standard",
		"Contype" : 2,
		"Operator" : "TAW",
	},{
		"Name" : "TAW 3",
		"Latitude" : 51.50746,
		"Longitude" : -0.12759,
		"Connect" : "BS345",
		"ChargeR" : "Standard",
		"Contype" : 3,
		"Operator" : "TAW",
	}
]

function initialize() {
    var latlng = new google.maps.LatLng(51.50746, -0.127594);
	var myOptions = {
		zoom: 17,
		center: latlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		mapTypeControl: true,
    };
	map = new google.maps.Map(document.getElementById('map'),myOptions);	
		
        markers = [];
		circles = [];
        for (var i = 0; i < json.length; i++) {
          var data = json[i],
			latLng = new google.maps.LatLng(data.Latitude, data.Longitude);
          var marker = new google.maps.Marker({
            position: latLng,
			map : map,
			title : data.Name,
						
          });
		  var circle = new google.maps.Circle({ 
			center: latLng,
			radius: 0.2*1.609344*1000, //convert 0.5 miles to meters
			map:map,
			fillOpacity: 0.0,
			strokeWidth: 5,
			title : data.Name,
		  });
		  	  
		   markers.push(marker);
		   circles.push(circle);
		   // end Looping through the JSON data
		   <!-- Map traffic begin -->		
		   // end Creating a closure	  		  
        }
		// var markerCluster = new MarkerClusterer(map, markers)	
		
		
		$('[name="contype"],[name="operator"]').click(function(){
		
		var criteria={contype:[],operator:[]};
		
		$.each(criteria,function(a,b){
		  $('[name="'+a+'"]').each(function(){
		    if(this.checked) criteria[this.name].push(this.value)
		  });
		})

		var expr=new RegExp('^('+criteria.operator.join('|')+') ('+criteria.contype.join('|')+')$');

		
		$.each(markers,function(){
		this.setMap(expr.test(this.getTitle())?map:null)
		});
		
		})
		
		$('[name="service"]').click(function() {
			for(var i = 0; i < circles.length; i++) {
				if (circles[i].getVisible()) { circles[i].setVisible(false); }
				else { circles[i].setVisible(true); }
			}
		
		})
}

google.maps.event.addDomListener(window, 'load', initialize);